Team Name: Bit Ballers
Jay Miller, Trevor Aron, Glen Smith, Bertha Hu

RUN THE GAME:
    python game.py

HOW TO PLAY:
    WASD to move
    Arrow keys to shoot
    Space to use activated item

HOW TO USE CONTROLLER:
    Go to options, configure joystick
    Press X to go to default keyboard
    Otherwise, press buttons on the joystick for
    each highlighted action. These will be your controls.

CHEATS TO HELP YOU OUT:
    To skip levels, press 0.
    To equip the laser, press 9.
    To equip the shield, press 8. 

