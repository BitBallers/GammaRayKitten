Gamma Ray Kitten
BitBallers

Trevor Aron
    taron1
Jay Miller
    jmill220

How to run:
    python game.py

How to play:
    WASD to move
    Arrow keys to shoot (directional)
    You need to get to the stairs in the level
    You need a key to open doors
    The syringe is a powerup

Level One Details
    Our level one is randomly generated. We have a bunch of premade squares (or rooms).
    Our level generation algorithim will then put them into a 3x3 grid, so the level
    is not the same each time! (Randomization is our whole gimmick!)
    This is our "true level 1" though, because level 2 will have a different
    collection of rooms that are chosen for level generation

Improvements:

    Blood Effects
        On killing an enemy, they explode with blood, and leave a permanent
        blood stain behind. This is acheived with some nice particle effects
    Powerup
        We added a "syringe" powerup that gives you three shots instead of one,
        giving a more shotgun feel
    Map Generation
        The map generation works by parsing submaps from map_collection.txt (in maps/texts)
        and then picking random submaps to make a 3x3 level grid!
    Drops
        Enemies will drop health hearts at a low percentage. The drop has a nice
        bounce animation. 
    Overlay
        We made the overlay stand out more by changing its color. We also added
        images to the overlay: if you have a key, it shows a key in the overlay,
        same with the syringe.
    Corrected Movement
        We realized that it was anoying for the player to simply get stuck when running
        against a wall if it is near the edge. Therefore, we added a movement correction,
        so if you run into a corner of the wall and there is no wall next to it,
        you will be moved slightly so you can keep moving straight!
